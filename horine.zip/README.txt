In order to run this program, put your data in a file named bin.txt, in the following format:

2             //the number of cases
10            //the size of the bins items are sorted into
6             //the number of items to sort
5 10 2 5 4 4  //a list of the weights of the items
10            //this format continues for as many cases as you have
4
3 8 2 7
